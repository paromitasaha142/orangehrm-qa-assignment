import { expect, Page } from '@playwright/test';

export class LoginPage {
  constructor(private readonly page: Page) {}

  private username = this.page.getByPlaceholder('Username');
  private password = this.page.getByPlaceholder('Password');
  private loginButton = this.page.getByRole('button', { name: 'Login' });

  async open() {
    await this.page.goto('/web/index.php/auth/login');
  }

  async login(username: string, password: string) {
    await this.username.fill(username);
    await this.password.fill(password);
    await this.loginButton.click();
  }

  async expectInvalidCredentials() {
    await expect(
      this.page.getByText('Invalid credentials', { exact: true })
    ).toBeVisible();
  }

  async expectDashboard() {
    await expect(this.page).toHaveURL(/dashboard\/index/);
  }
}
